"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { QrCode, Check, Star, Zap, Users, Crown, ArrowRight, Palette, BarChart3, Headphones } from "lucide-react"
import Link from "next/link"

export default function PlanosPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <QrCode className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground font-serif">TaskQR</h1>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Início
              </Link>
              <Link href="/recursos" className="text-muted-foreground hover:text-foreground transition-colors">
                Recursos
              </Link>
              <Link href="/planos" className="text-foreground font-medium">
                Planos
              </Link>
              <Link href="/login" className="text-muted-foreground hover:text-foreground transition-colors">
                Login
              </Link>
              <Link href="/cadastro">
                <Button size="sm">Cadastro</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 font-serif">Escolha o Plano Ideal</h1>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
            Desde uso básico até recursos empresariais avançados. Encontre o plano perfeito para suas necessidades.
          </p>
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Plano Grátis */}
            <Card className="p-8 relative">
              <CardContent className="pt-6">
                <div className="text-center mb-8">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Zap className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">Grátis</h3>
                  <p className="text-muted-foreground mb-4">Perfeito para uso pessoal</p>
                  <div className="text-4xl font-bold text-foreground mb-2">R$ 0</div>
                  <p className="text-sm text-muted-foreground">Para sempre</p>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Até 5 QR Codes por mês</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Geração básica de QR Codes</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Download em PNG</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Personalização básica</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Suporte por email</span>
                  </div>
                </div>

                <Link href="/cadastro">
                  <Button variant="outline" className="w-full bg-transparent">
                    Começar Grátis
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Plano Premium - RECOMENDADO */}
            <Card className="p-8 relative border-primary shadow-lg scale-105">
              <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground">
                <Star className="w-3 h-3 mr-1" />
                Mais Popular
              </Badge>
              <CardContent className="pt-6">
                <div className="text-center mb-8">
                  <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Crown className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">Premium</h3>
                  <p className="text-muted-foreground mb-4">Para profissionais e pequenas empresas</p>
                  <div className="text-4xl font-bold text-foreground mb-2">R$ 29</div>
                  <p className="text-sm text-muted-foreground">por mês</p>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">QR Codes ilimitados</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Personalização avançada</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Analytics e estatísticas</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Histórico de QR Codes</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Suporte prioritário</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">API de integração</span>
                  </div>
                </div>

                <Link href="/cadastro">
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    Começar Premium
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Plano Empresarial */}
            <Card className="p-8 relative">
              <CardContent className="pt-6">
                <div className="text-center mb-8">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500/20 to-purple-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Users className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">Empresarial</h3>
                  <p className="text-muted-foreground mb-4">Para grandes equipes e empresas</p>
                  <div className="text-4xl font-bold text-foreground mb-2">R$ 99</div>
                  <p className="text-sm text-muted-foreground">por mês</p>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Tudo do Premium +</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Integração Google Drive</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Integração Google Docs</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Gerenciamento de equipes</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Relatórios avançados</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">Suporte dedicado 24/7</span>
                  </div>
                </div>

                <Link href="/cadastro">
                  <Button
                    variant="outline"
                    className="w-full border-purple-600 text-purple-600 hover:bg-purple-50 bg-transparent"
                  >
                    Falar com Vendas
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Compare os Recursos</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Veja em detalhes o que cada plano oferece</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Palette className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Personalização Avançada</h4>
                    <p className="text-sm text-muted-foreground mb-3">
                      Customize cores, logos e estilos dos seus QR Codes
                    </p>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Grátis:</span>
                        <span className="text-muted-foreground">Básico</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Premium:</span>
                        <span className="text-green-600">Completo</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Empresarial:</span>
                        <span className="text-green-600">Completo</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <BarChart3 className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Analytics e Relatórios</h4>
                    <p className="text-sm text-muted-foreground mb-3">Acompanhe o desempenho dos seus QR Codes</p>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Grátis:</span>
                        <span className="text-red-500">Não</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Premium:</span>
                        <span className="text-green-600">Sim</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Empresarial:</span>
                        <span className="text-green-600">Avançado</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Headphones className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Suporte Técnico</h4>
                    <p className="text-sm text-muted-foreground mb-3">Ajuda quando você mais precisa</p>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Grátis:</span>
                        <span className="text-muted-foreground">Email</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Premium:</span>
                        <span className="text-green-600">Prioritário</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Empresarial:</span>
                        <span className="text-green-600">24/7</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Perguntas Frequentes</h2>
            <p className="text-muted-foreground">Tire suas dúvidas sobre nossos planos</p>
          </div>

          <div className="space-y-6">
            <Card className="p-6">
              <CardContent className="pt-6">
                <h4 className="font-semibold text-foreground mb-3">
                  Posso cancelar minha assinatura a qualquer momento?
                </h4>
                <p className="text-muted-foreground">
                  Sim! Você pode cancelar sua assinatura a qualquer momento sem taxas de cancelamento. Seus QR Codes
                  continuarão funcionando até o final do período pago.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <h4 className="font-semibold text-foreground mb-3">Os QR Codes param de funcionar se eu cancelar?</h4>
                <p className="text-muted-foreground">
                  Não! Todos os QR Codes que você criou continuarão funcionando normalmente. Você apenas não poderá
                  criar novos QR Codes com recursos premium.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <h4 className="font-semibold text-foreground mb-3">Existe desconto para pagamento anual?</h4>
                <p className="text-muted-foreground">
                  Sim! Oferecemos 20% de desconto para assinaturas anuais. Entre em contato conosco para mais detalhes
                  sobre preços anuais.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 bg-primary/5">
        <div className="container mx-auto text-center max-w-4xl">
          <h2 className="text-3xl font-bold text-foreground mb-6 font-serif">Pronto para começar?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Escolha seu plano e comece a organizar com QR Codes hoje mesmo
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/cadastro">
              <Button size="lg" className="text-lg px-8 py-6">
                <QrCode className="mr-2 h-5 w-5" />
                Começar Grátis
              </Button>
            </Link>
            <Link href="/#contato">
              <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                Falar com Vendas
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
