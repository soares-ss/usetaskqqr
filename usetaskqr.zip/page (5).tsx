"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { QrCode, Play, CheckSquare, Zap, Palette, Cloud, ArrowRight, Smartphone, Monitor, Users } from "lucide-react"
import Link from "next/link"

export default function RecursosPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <QrCode className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground font-serif">TaskQR</h1>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Início
              </Link>
              <Link href="/recursos" className="text-foreground font-medium">
                Recursos
              </Link>
              <Link href="/planos" className="text-muted-foreground hover:text-foreground transition-colors">
                Planos
              </Link>
              <Link href="/login" className="text-muted-foreground hover:text-foreground transition-colors">
                Login
              </Link>
              <Link href="/cadastro">
                <Button size="sm">Cadastro</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 font-serif">
            Recursos Poderosos do TaskQR
          </h1>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
            Descubra todas as funcionalidades que fazem do TaskQR a melhor plataforma para organização com QR Codes
          </p>
        </div>
      </section>

      {/* Main Features */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* QR Code Dinâmico */}
            <Card className="p-8 hover:shadow-lg transition-all duration-300 group">
              <CardContent className="pt-6">
                <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <QrCode className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground mb-4 text-center">
                  QR Code Dinâmico Personalizado
                </h3>
                <p className="text-muted-foreground mb-6 leading-relaxed text-center">
                  Crie QR Codes únicos e personalizados para qualquer tipo de conteúdo. Totalmente customizável e
                  otimizado para diferentes usos.
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Geração em tempo real</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Download em alta qualidade (PNG)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Compatível com todos os leitores</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Funciona offline quando impresso</span>
                  </div>
                </div>

                <Link href="/#gerador">
                  <Button className="w-full group-hover:bg-primary/90 transition-colors">
                    Testar Agora
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Multimídia Integrada */}
            <Card className="p-8 hover:shadow-lg transition-all duration-300 group">
              <CardContent className="pt-6">
                <div className="w-20 h-20 bg-gradient-to-br from-green-500/20 to-green-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Play className="h-10 w-10 text-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground mb-4 text-center">Multimídia Integrada</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed text-center">
                  Conecte seus QR Codes a vídeos, áudios, documentos e links. Perfeito para materiais educacionais e
                  apresentações.
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Vídeos do YouTube e Vimeo</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Arquivos de áudio (MP3, WAV)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Documentos PDF e Word</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Links para sites e aplicativos</span>
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full group-hover:border-green-600 group-hover:text-green-600 transition-colors bg-transparent"
                >
                  Saiba Mais
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>

            {/* Checklist Interativo */}
            <Card className="p-8 hover:shadow-lg transition-all duration-300 group">
              <CardContent className="pt-6">
                <div className="w-20 h-20 bg-gradient-to-br from-orange-500/20 to-orange-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <CheckSquare className="h-10 w-10 text-orange-600" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground mb-4 text-center">Checklist Interativo</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed text-center">
                  Transforme suas tarefas em checklists interativos acessíveis via QR Code. Ideal para processos e
                  rotinas.
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Listas de tarefas organizadas</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Progresso visual em tempo real</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Compartilhamento com equipes</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                    <span className="text-sm text-muted-foreground">Histórico de conclusões</span>
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full group-hover:border-orange-600 group-hover:text-orange-600 transition-colors bg-transparent"
                >
                  Saiba Mais
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Additional Features */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Recursos Adicionais</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Funcionalidades extras que tornam o TaskQR ainda mais poderoso
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Zap className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Geração Instantânea</h4>
                    <p className="text-sm text-muted-foreground">
                      QR Codes gerados em tempo real conforme você digita, sem delays ou carregamentos.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Palette className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Personalização Visual</h4>
                    <p className="text-sm text-muted-foreground">
                      Customize cores e estilos dos seus QR Codes para combinar com sua marca.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Cloud className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Sem Armazenamento</h4>
                    <p className="text-sm text-muted-foreground">
                      Seus dados não são armazenados. Tudo é processado localmente no seu navegador.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Smartphone className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">100% Responsivo</h4>
                    <p className="text-sm text-muted-foreground">
                      Funciona perfeitamente em celulares, tablets e computadores.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Monitor className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Interface Intuitiva</h4>
                    <p className="text-sm text-muted-foreground">
                      Design limpo e fácil de usar, sem curva de aprendizado.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Compartilhamento Fácil</h4>
                    <p className="text-sm text-muted-foreground">
                      Compartilhe QR Codes digitalmente ou imprima para uso offline.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <h2 className="text-3xl font-bold text-foreground mb-6 font-serif">Pronto para começar?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Experimente todos esses recursos gratuitamente agora mesmo
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/#gerador">
              <Button size="lg" className="text-lg px-8 py-6">
                <QrCode className="mr-2 h-5 w-5" />
                Criar QR Code Grátis
              </Button>
            </Link>
            <Link href="/planos">
              <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                Ver Planos Premium
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
