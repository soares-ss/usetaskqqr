"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Download, QrCode, Link, FileText, Video, Music, FileCheck, Phone, Wifi, Plus, X } from "lucide-react"
import QRCode from "qrcode"

type ContentType = "texto" | "link" | "video" | "audio" | "lista" | "documento" | "contato" | "wifi"

interface ListItem {
  id: string
  text: string
}

export default function QRGenerator() {
  const [contentType, setContentType] = useState<ContentType>("texto")
  const [inputText, setInputText] = useState("")
  const [qrCodeUrl, setQrCodeUrl] = useState("")
  const [listItems, setListItems] = useState<ListItem[]>([{ id: "1", text: "" }])
  const [contactData, setContactData] = useState({
    name: "",
    phone: "",
    email: "",
    organization: "",
    url: "",
  })
  const [wifiData, setWifiData] = useState({
    ssid: "",
    password: "",
    security: "WPA",
    hidden: false,
  })
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Generate QR code in real-time
  useEffect(() => {
    const content = getContentForQR()
    if (content.trim()) {
      generateQRCode(content)
    } else {
      setQrCodeUrl("")
    }
  }, [contentType, inputText, listItems, contactData, wifiData])

  const getContentForQR = (): string => {
    switch (contentType) {
      case "texto":
      case "link":
      case "video":
      case "audio":
      case "documento":
        return inputText
      case "lista":
        const validItems = listItems.filter((item) => item.text.trim())
        return validItems.map((item, index) => `${index + 1}. ${item.text}`).join("\n")
      case "contato":
        // vCard format
        const vcard = [
          "BEGIN:VCARD",
          "VERSION:3.0",
          contactData.name && `FN:${contactData.name}`,
          contactData.phone && `TEL:${contactData.phone}`,
          contactData.email && `EMAIL:${contactData.email}`,
          contactData.organization && `ORG:${contactData.organization}`,
          contactData.url && `URL:${contactData.url}`,
          "END:VCARD",
        ]
          .filter(Boolean)
          .join("\n")
        return vcard
      case "wifi":
        // WiFi QR format
        return `WIFI:T:${wifiData.security};S:${wifiData.ssid};P:${wifiData.password};H:${wifiData.hidden ? "true" : "false"};;`
      default:
        return inputText
    }
  }

  const generateQRCode = async (text: string) => {
    try {
      const canvas = canvasRef.current
      if (canvas) {
        await QRCode.toCanvas(canvas, text, {
          width: 256,
          margin: 2,
          color: {
            dark: "#1E3A8A", // Using our primary blue color
            light: "#FFFFFF",
          },
        })
        const dataUrl = canvas.toDataURL("image/png")
        setQrCodeUrl(dataUrl)
      }
    } catch (error) {
      console.error("Erro ao gerar QR Code:", error)
    }
  }

  const downloadQRCode = () => {
    if (qrCodeUrl) {
      const link = document.createElement("a")
      const fileName = `taskqr-${contentType}-${Date.now()}.png`
      link.download = fileName
      link.href = qrCodeUrl
      link.click()
    }
  }

  const addListItem = () => {
    const newId = (listItems.length + 1).toString()
    setListItems([...listItems, { id: newId, text: "" }])
  }

  const removeListItem = (id: string) => {
    if (listItems.length > 1) {
      setListItems(listItems.filter((item) => item.id !== id))
    }
  }

  const updateListItem = (id: string, text: string) => {
    setListItems(listItems.map((item) => (item.id === id ? { ...item, text } : item)))
  }

  const getContentTypeIcon = (type: ContentType) => {
    switch (type) {
      case "texto":
        return <FileText className="h-4 w-4" />
      case "link":
        return <Link className="h-4 w-4" />
      case "video":
        return <Video className="h-4 w-4" />
      case "audio":
        return <Music className="h-4 w-4" />
      case "lista":
        return <FileCheck className="h-4 w-4" />
      case "documento":
        return <FileText className="h-4 w-4" />
      case "contato":
        return <Phone className="h-4 w-4" />
      case "wifi":
        return <Wifi className="h-4 w-4" />
      default:
        return <QrCode className="h-4 w-4" />
    }
  }

  const renderContentInput = () => {
    switch (contentType) {
      case "lista":
        return (
          <div className="space-y-4">
            <Label>Itens da Lista</Label>
            {listItems.map((item, index) => (
              <div key={item.id} className="flex gap-2">
                <Input
                  placeholder={`Item ${index + 1}`}
                  value={item.text}
                  onChange={(e) => updateListItem(item.id, e.target.value)}
                  className="flex-1"
                />
                {listItems.length > 1 && (
                  <Button variant="outline" size="sm" onClick={() => removeListItem(item.id)} className="px-2">
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button variant="outline" onClick={addListItem} className="w-full bg-transparent">
              <Plus className="mr-2 h-4 w-4" />
              Adicionar Item
            </Button>
          </div>
        )

      case "contato":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="contact-name">Nome Completo</Label>
              <Input
                id="contact-name"
                placeholder="João Silva"
                value={contactData.name}
                onChange={(e) => setContactData({ ...contactData, name: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="contact-phone">Telefone</Label>
              <Input
                id="contact-phone"
                placeholder="+55 11 99999-9999"
                value={contactData.phone}
                onChange={(e) => setContactData({ ...contactData, phone: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="contact-email">E-mail</Label>
              <Input
                id="contact-email"
                type="email"
                placeholder="joao@exemplo.com"
                value={contactData.email}
                onChange={(e) => setContactData({ ...contactData, email: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="contact-org">Empresa/Organização</Label>
              <Input
                id="contact-org"
                placeholder="Minha Empresa Ltda"
                value={contactData.organization}
                onChange={(e) => setContactData({ ...contactData, organization: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="contact-url">Website</Label>
              <Input
                id="contact-url"
                placeholder="https://www.exemplo.com"
                value={contactData.url}
                onChange={(e) => setContactData({ ...contactData, url: e.target.value })}
              />
            </div>
          </div>
        )

      case "wifi":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="wifi-ssid">Nome da Rede (SSID)</Label>
              <Input
                id="wifi-ssid"
                placeholder="MinhaRedeWiFi"
                value={wifiData.ssid}
                onChange={(e) => setWifiData({ ...wifiData, ssid: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="wifi-password">Senha</Label>
              <Input
                id="wifi-password"
                type="password"
                placeholder="senha123"
                value={wifiData.password}
                onChange={(e) => setWifiData({ ...wifiData, password: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="wifi-security">Tipo de Segurança</Label>
              <Select
                value={wifiData.security}
                onValueChange={(value) => setWifiData({ ...wifiData, security: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="WPA">WPA/WPA2</SelectItem>
                  <SelectItem value="WEP">WEP</SelectItem>
                  <SelectItem value="nopass">Sem senha</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="wifi-hidden"
                checked={wifiData.hidden}
                onChange={(e) => setWifiData({ ...wifiData, hidden: e.target.checked })}
                className="rounded"
              />
              <Label htmlFor="wifi-hidden">Rede oculta</Label>
            </div>
          </div>
        )

      default:
        return (
          <div>
            <Label htmlFor="qr-input">
              {contentType === "link" && "URL ou Link"}
              {contentType === "video" && "Link do Vídeo (YouTube, Vimeo, etc.)"}
              {contentType === "audio" && "Link do Áudio ou Música"}
              {contentType === "documento" && "Link do Documento (PDF, Word, etc.)"}
              {contentType === "texto" && "Texto ou Conteúdo Personalizado"}
            </Label>
            <Textarea
              id="qr-input"
              placeholder={
                contentType === "link"
                  ? "https://www.exemplo.com"
                  : contentType === "video"
                    ? "https://www.youtube.com/watch?v=..."
                    : contentType === "audio"
                      ? "https://soundcloud.com/..."
                      : contentType === "documento"
                        ? "https://drive.google.com/file/d/..."
                        : "Digite aqui seu conteúdo..."
              }
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="min-h-[120px] resize-none"
            />
          </div>
        )
    }
  }

  const getExampleButtons = () => {
    switch (contentType) {
      case "link":
        return [
          { label: "Google", value: "https://www.google.com" },
          { label: "YouTube", value: "https://www.youtube.com" },
          { label: "GitHub", value: "https://github.com" },
        ]
      case "video":
        return [
          { label: "YouTube", value: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" },
          { label: "Vimeo", value: "https://vimeo.com/123456789" },
        ]
      case "audio":
        return [
          { label: "Spotify", value: "https://open.spotify.com/track/..." },
          { label: "SoundCloud", value: "https://soundcloud.com/..." },
        ]
      case "documento":
        return [
          { label: "Google Docs", value: "https://docs.google.com/document/d/..." },
          { label: "PDF", value: "https://exemplo.com/documento.pdf" },
        ]
      case "texto":
        return [
          { label: "Mensagem", value: "Bem-vindo ao TaskQR! Esta é uma mensagem de exemplo." },
          { label: "Instruções", value: "1. Escaneie este código\n2. Siga as instruções\n3. Complete a tarefa" },
        ]
      default:
        return []
    }
  }

  return (
    <section id="gerador" className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Gerador de QR Code Avançado</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Crie QR Codes personalizados para diferentes tipos de conteúdo. Escolha o tipo e personalize conforme sua
            necessidade.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Content Type Selection */}
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Tipo de Conteúdo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
                  {[
                    { type: "texto" as ContentType, label: "Texto", icon: <FileText className="h-4 w-4" /> },
                    { type: "link" as ContentType, label: "Link", icon: <Link className="h-4 w-4" /> },
                    { type: "video" as ContentType, label: "Vídeo", icon: <Video className="h-4 w-4" /> },
                    { type: "audio" as ContentType, label: "Áudio", icon: <Music className="h-4 w-4" /> },
                    { type: "lista" as ContentType, label: "Lista", icon: <FileCheck className="h-4 w-4" /> },
                    { type: "documento" as ContentType, label: "Documento", icon: <FileText className="h-4 w-4" /> },
                    { type: "contato" as ContentType, label: "Contato", icon: <Phone className="h-4 w-4" /> },
                    { type: "wifi" as ContentType, label: "WiFi", icon: <Wifi className="h-4 w-4" /> },
                  ].map((item) => (
                    <Button
                      key={item.type}
                      variant={contentType === item.type ? "default" : "outline"}
                      onClick={() => setContentType(item.type)}
                      className="flex flex-col gap-2 h-auto py-3 px-2"
                    >
                      {item.icon}
                      <span className="text-xs">{item.label}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {getContentTypeIcon(contentType)}
                  Configurar Conteúdo
                  <Badge variant="secondary" className="ml-auto">
                    {contentType.charAt(0).toUpperCase() + contentType.slice(1)}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {renderContentInput()}

                {/* Example buttons for applicable content types */}
                {getExampleButtons().length > 0 && (
                  <div className="pt-4 border-t">
                    <Label className="text-sm text-muted-foreground mb-2 block">Exemplos rápidos:</Label>
                    <div className="flex flex-wrap gap-2">
                      {getExampleButtons().map((example, index) => (
                        <Button key={index} variant="outline" size="sm" onClick={() => setInputText(example.value)}>
                          {example.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* QR Code Display Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <QrCode className="h-5 w-5" />
                  Seu QR Code
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center space-y-4">
                  {getContentForQR().trim() ? (
                    <>
                      <div className="bg-white p-6 rounded-lg border-2 border-border shadow-sm">
                        <canvas
                          ref={canvasRef}
                          className="max-w-full h-auto"
                          style={{ display: qrCodeUrl ? "block" : "none" }}
                        />
                      </div>

                      <div className="w-full space-y-3">
                        <Button onClick={downloadQRCode} disabled={!qrCodeUrl} className="w-full">
                          <Download className="mr-2 h-4 w-4" />
                          Baixar QR Code (PNG)
                        </Button>

                        <div className="text-center">
                          <Badge variant="outline" className="text-xs">
                            {contentType.toUpperCase()} • {getContentForQR().length} caracteres
                          </Badge>
                        </div>
                      </div>

                      <p className="text-sm text-muted-foreground text-center">
                        QR Code gerado com sucesso! Funciona em qualquer leitor de QR Code.
                      </p>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-64 text-center">
                      {getContentTypeIcon(contentType)}
                      <div className="mt-4">
                        <QrCode className="h-16 w-16 text-muted-foreground/50 mb-4 mx-auto" />
                        <p className="text-muted-foreground">
                          {contentType === "lista"
                            ? "Adicione itens à sua lista"
                            : contentType === "contato"
                              ? "Preencha os dados de contato"
                              : contentType === "wifi"
                                ? "Configure os dados da rede WiFi"
                                : "Preencha o conteúdo para gerar seu QR Code"}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Clear All Button */}
          <div className="mt-8 text-center">
            <Button
              variant="outline"
              onClick={() => {
                setInputText("")
                setListItems([{ id: "1", text: "" }])
                setContactData({ name: "", phone: "", email: "", organization: "", url: "" })
                setWifiData({ ssid: "", password: "", security: "WPA", hidden: false })
              }}
            >
              <X className="mr-2 h-4 w-4" />
              Limpar Tudo
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
