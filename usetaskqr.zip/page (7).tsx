"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  QrCode,
  Scan,
  Users,
  GraduationCap,
  Building2,
  Edit3,
  Zap,
  Smartphone,
  Shield,
  Wifi,
  CheckCircle,
  Heart,
  Target,
  Lightbulb,
  Instagram,
  Mail,
} from "lucide-react"
import QRGenerator from "@/components/qr-generator"
import ContactForm from "@/components/contact-form"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <QrCode className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground font-serif">TaskQR</h1>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/" className="text-foreground font-medium">
                Início
              </Link>
              <Link href="/recursos" className="text-muted-foreground hover:text-foreground transition-colors">
                Recursos
              </Link>
              <Link href="/planos" className="text-muted-foreground hover:text-foreground transition-colors">
                Planos
              </Link>
              <Link href="/login" className="text-muted-foreground hover:text-foreground transition-colors">
                Login
              </Link>
              <Link href="/cadastro">
                <Button size="sm">Cadastro</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <div className="mb-8">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 font-serif">TaskQR</h1>
            <p className="text-2xl md:text-3xl text-primary font-medium mb-8">Organize com um scan</p>
            <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
              Uma plataforma que facilita a organização de tarefas, estudos e projetos usando QR Codes personalizados.
              Simples, rápido e acessível para todos.
            </p>
          </div>

          <Button
            size="lg"
            className="text-lg px-8 py-6 mb-16"
            onClick={() => document.getElementById("gerador")?.scrollIntoView({ behavior: "smooth" })}
          >
            <Scan className="mr-2 h-5 w-5" />
            Crie seu QR Code agora
          </Button>

          {/* Quick Preview */}
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <Card className="p-6 text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <QrCode className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Crie QR Codes</h3>
                <p className="text-sm text-muted-foreground">
                  Gere códigos personalizados para suas tarefas e projetos
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Scan className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Escaneie e Acesse</h3>
                <p className="text-sm text-muted-foreground">Acesso instantâneo ao conteúdo com um simples scan</p>
              </CardContent>
            </Card>

            <Card className="p-6 text-center">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Organize Tudo</h3>
                <p className="text-sm text-muted-foreground">Mantenha suas tarefas e projetos sempre organizados</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* QR Generator Section */}
      <section id="gerador" className="py-16">
        <div className="container mx-auto px-4">
          <QRGenerator />
        </div>
      </section>

      {/* How It Works Section */}
      <section id="como-funciona" className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Como Funciona</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Criar e usar QR Codes nunca foi tão simples. Siga estes 3 passos e organize sua vida digital.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8 relative">
              {/* Step 1 */}
              <div className="text-center relative">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                    <Edit3 className="h-10 w-10 text-primary-foreground" />
                  </div>
                  <div className="absolute top-10 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                    <span className="text-primary font-bold text-lg">1</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Insira seu Conteúdo</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Digite qualquer texto, link, informação de contato ou conteúdo que você deseja transformar em QR Code.
                  Pode ser um link para um documento, uma mensagem ou qualquer dado importante.
                </p>
              </div>

              {/* Connection Line 1 */}
              <div className="hidden md:block absolute top-10 left-1/3 w-1/3 h-0.5 bg-primary/30 transform translate-x-1/2"></div>

              {/* Step 2 */}
              <div className="text-center relative">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                    <Zap className="h-10 w-10 text-primary-foreground" />
                  </div>
                  <div className="absolute top-10 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                    <span className="text-primary font-bold text-lg">2</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Gere o Código</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Nosso sistema gera automaticamente seu QR Code personalizado em tempo real. Visualize o resultado
                  instantaneamente e faça o download em formato PNG de alta qualidade.
                </p>
              </div>

              {/* Connection Line 2 */}
              <div className="hidden md:block absolute top-10 right-1/3 w-1/3 h-0.5 bg-primary/30 transform -translate-x-1/2"></div>

              {/* Step 3 */}
              <div className="text-center relative">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 relative z-10">
                    <Smartphone className="h-10 w-10 text-primary-foreground" />
                  </div>
                  <div className="absolute top-10 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                    <span className="text-primary font-bold text-lg">3</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Use Digital ou Impresso</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Compartilhe digitalmente ou imprima seu QR Code. Funciona perfeitamente em qualquer dispositivo e até
                  mesmo offline quando impresso. Acesso instantâneo sempre que precisar.
                </p>
              </div>
            </div>

            {/* Benefits Cards */}
            <div className="grid md:grid-cols-2 gap-6 mt-16">
              <Card className="p-6">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Zap className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Rápido e Eficiente</h4>
                      <p className="text-sm text-muted-foreground">
                        Gere QR Codes em segundos, sem complicações. Interface intuitiva e processo simplificado.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="p-6">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">Acessível para Todos</h4>
                      <p className="text-sm text-muted-foreground">
                        Não precisa de cadastro ou login contínuo. Use quando quiser, como quiser.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases and Benefits Section */}
      <section id="casos-de-uso" className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Casos de Uso</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Descubra como o TaskQR pode transformar a organização em diferentes áreas da sua vida
            </p>
          </div>

          {/* Detailed Use Cases */}
          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
            {/* Students */}
            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <GraduationCap className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground mb-4">Estudantes</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Organize materiais de estudo, links importantes e cronogramas de forma prática
                </p>

                <div className="space-y-3 text-left">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Materiais de Estudo:</strong> Links para PDFs, vídeos e recursos online
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Cronogramas:</strong> Acesso rápido a calendários e prazos importantes
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Grupos de Estudo:</strong> Compartilhe informações facilmente com colegas
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Bibliotecas:</strong> Organize referências e citações importantes
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Teachers */}
            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground mb-4">Professores</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Compartilhe recursos educacionais e atividades com seus alunos de forma eficiente
                </p>

                <div className="space-y-3 text-left">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Material Didático:</strong> Distribua apostilas e exercícios instantaneamente
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Atividades Online:</strong> Links para formulários e pesquisas educacionais
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Comunicação:</strong> Contato direto com pais e responsáveis
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Recursos Extras:</strong> Vídeos complementares e materiais de apoio
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Companies */}
            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Building2 className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground mb-4">Empresas</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Facilite o acesso a documentos, processos e informações corporativas
                </p>

                <div className="space-y-3 text-left">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Documentos Internos:</strong> Manuais, políticas e procedimentos
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Treinamentos:</strong> Links para cursos e materiais de capacitação
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Eventos Corporativos:</strong> Informações e cronogramas de reuniões
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-muted-foreground">
                      <strong>Contatos Importantes:</strong> Informações de departamentos e equipes
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Benefits Section */}
          <div className="text-center mb-12">
            <h3 className="text-2xl font-bold text-foreground mb-4 font-serif">Por que escolher o TaskQR?</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">Benefícios que fazem a diferença no seu dia a dia</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {/* Fast */}
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-3">Rápido</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Gere QR Codes em segundos. Interface intuitiva que não perde tempo com complicações desnecessárias.
                </p>
              </CardContent>
            </Card>

            {/* Accessible */}
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-3">Acessível</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Sem necessidade de cadastro ou login contínuo. Use quando quiser, como quiser, sem barreiras.
                </p>
              </CardContent>
            </Card>

            {/* No Login Required */}
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-3">Sem Login</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Privacidade garantida. Não armazenamos seus dados pessoais nem exigimos cadastros complexos.
                </p>
              </CardContent>
            </Card>

            {/* Works Offline */}
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Wifi className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-3">Funciona Offline</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  QR Codes impressos funcionam sem internet. Acesso garantido mesmo em locais sem conectividade.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Call to Action */}
          <div className="text-center mt-16">
            <Button
              size="lg"
              className="text-lg px-8 py-6"
              onClick={() => document.getElementById("gerador")?.scrollIntoView({ behavior: "smooth" })}
            >
              <QrCode className="mr-2 h-5 w-5" />
              Comece a usar agora
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Sobre o TaskQR</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Conheça nossa missão de simplificar a organização através da tecnologia QR Code
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <Card className="p-6 text-center">
                <CardContent className="pt-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Target className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">Nossa Missão</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Democratizar o acesso à tecnologia QR Code, tornando a organização de informações simples e
                    acessível para todos.
                  </p>
                </CardContent>
              </Card>

              <Card className="p-6 text-center">
                <CardContent className="pt-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Lightbulb className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">Nossa Visão</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Ser a plataforma de referência para criação de QR Codes no Brasil, conectando o mundo físico ao
                    digital.
                  </p>
                </CardContent>
              </Card>

              <Card className="p-6 text-center">
                <CardContent className="pt-6">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-3">Nossos Valores</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Simplicidade, acessibilidade e privacidade. Acreditamos que a tecnologia deve servir às pessoas.
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card className="p-8">
              <CardContent className="pt-6">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-semibold text-foreground mb-4">Por que criamos o TaskQR?</h3>
                </div>
                <div className="prose prose-lg max-w-none text-muted-foreground">
                  <p className="mb-4 leading-relaxed">
                    O TaskQR nasceu da necessidade de simplificar a forma como compartilhamos e organizamos informações
                    no dia a dia. Percebemos que muitas pessoas enfrentavam dificuldades para organizar links,
                    documentos e informações importantes de forma prática e acessível.
                  </p>
                  <p className="mb-4 leading-relaxed">
                    Nossa plataforma foi desenvolvida pensando em estudantes que precisam organizar materiais de estudo,
                    professores que desejam compartilhar recursos com facilidade, e empresas que buscam otimizar
                    processos internos. Tudo isso sem complicações, cadastros desnecessários ou barreiras tecnológicas.
                  </p>
                  <p className="leading-relaxed">
                    Acreditamos que a tecnologia QR Code tem o poder de conectar o mundo físico ao digital de forma
                    simples e eficiente. Com o TaskQR, qualquer pessoa pode criar, compartilhar e organizar informações
                    com apenas um scan.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-4 font-serif">Contato</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Tem dúvidas, sugestões ou feedback? Adoraríamos ouvir você!
            </p>
          </div>

          <ContactForm />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <QrCode className="h-8 w-8 text-primary" />
                <h3 className="text-xl font-bold text-foreground font-serif">TaskQR</h3>
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                Organize com um scan. A plataforma que facilita a organização de tarefas, estudos e projetos usando QR
                Codes personalizados.
              </p>
              <p className="text-xs text-muted-foreground">
                © <span id="current-year">2025</span> TaskQR. Todos os direitos reservados.
              </p>
            </div>

            {/* Navigation Links */}
            <div className="md:col-span-1">
              <h4 className="font-semibold text-foreground mb-4">Navegação</h4>
              <ul className="space-y-2">
                <li>
                  <Link
                    href="/#gerador"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Gerador de QR Code
                  </Link>
                </li>
                <li>
                  <Link
                    href="/recursos"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Recursos
                  </Link>
                </li>
                <li>
                  <Link
                    href="/planos"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Planos
                  </Link>
                </li>
                <li>
                  <Link
                    href="/#sobre"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Sobre Nós
                  </Link>
                </li>
                <li>
                  <Link
                    href="/#contato"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Contato
                  </Link>
                </li>
              </ul>
            </div>

            {/* Resources */}
            <div className="md:col-span-1">
              <h4 className="font-semibold text-foreground mb-4">Recursos</h4>
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => document.getElementById("gerador")?.scrollIntoView({ behavior: "smooth" })}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors text-left"
                  >
                    Criar QR Code Grátis
                  </button>
                </li>
                <li>
                  <Link
                    href="/#casos-de-uso"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Exemplos de Uso
                  </Link>
                </li>
                <li>
                  <Link
                    href="/#sobre"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Nossa Missão
                  </Link>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    onClick={(e) => {
                      e.preventDefault()
                      alert(
                        "Política de Privacidade: O TaskQR não armazena dados pessoais. Todos os QR Codes são gerados localmente no seu navegador. Não coletamos, armazenamos ou compartilhamos informações pessoais dos usuários.",
                      )
                    }}
                  >
                    Política de Privacidade
                  </a>
                </li>
              </ul>
            </div>

            {/* Contact & Social */}
            <div className="md:col-span-1">
              <h4 className="font-semibold text-foreground mb-4">Conecte-se</h4>
              <div className="space-y-3">
                {/* Email */}
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Mail className="h-4 w-4 text-primary" />
                  </div>
                  <a
                    href="mailto:usetaskqr@gmail.com"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    usetaskqr@gmail.com
                  </a>
                </div>

                {/* Instagram */}
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Instagram className="h-4 w-4 text-primary" />
                  </div>
                  <a
                    href="https://instagram.com/usetaskqr"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    @usetaskqr
                  </a>
                </div>

                {/* TikTok */}
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <svg className="h-4 w-4 text-primary" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-.88-.05A6.33 6.33 0 0 0 5.16 20.5a6.34 6.34 0 0 0 10.86-4.43V7.83a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.26z" />
                    </svg>
                  </div>
                  <a
                    href="https://tiktok.com/@usetaskqr"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    @usetaskqr
                  </a>
                </div>
              </div>

              {/* Call to Action */}
              <div className="mt-6">
                <Button
                  size="sm"
                  className="w-full"
                  onClick={() => document.getElementById("gerador")?.scrollIntoView({ behavior: "smooth" })}
                >
                  <QrCode className="mr-2 h-4 w-4" />
                  Criar QR Code
                </Button>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-border mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="text-xs text-muted-foreground">Feito com ❤️ para facilitar sua organização digital</div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <button
                  onClick={(e) => {
                    e.preventDefault()
                    alert(
                      "Política de Privacidade: O TaskQR não armazena dados pessoais. Todos os QR Codes são gerados localmente no seu navegador. Não coletamos, armazenamos ou compartilhamos informações pessoais dos usuários.",
                    )
                  }}
                  className="hover:text-foreground transition-colors"
                >
                  Política de Privacidade
                </button>
                <span>•</span>
                <button
                  onClick={(e) => {
                    e.preventDefault()
                    alert(
                      "Termos de Uso: O TaskQR é uma ferramenta gratuita para criação de QR Codes. Use de forma responsável e respeitando as leis aplicáveis. Não nos responsabilizamos pelo conteúdo dos QR Codes criados pelos usuários.",
                    )
                  }}
                  className="hover:text-foreground transition-colors"
                >
                  Termos de Uso
                </button>
                <span>•</span>
                <Link href="/#contato" className="hover:text-foreground transition-colors">
                  Suporte
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <script
        dangerouslySetInnerHTML={{
          __html: `
            document.addEventListener('DOMContentLoaded', function() {
              const yearElement = document.getElementById('current-year');
              if (yearElement) {
                yearElement.textContent = new Date().getFullYear();
              }
            });
          `,
        }}
      />
    </div>
  )
}
